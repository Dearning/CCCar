create definer = root@localhost view carinfo as
select `i`.`car_id`        AS `car_id`,
       `n`.`net_id`        AS `net_id`,
       `n`.`net_name`      AS `net_name`,
       `c`.`category_Id`   AS `category_id`,
       `c`.`category_Name` AS `category_name`,
       `i`.`type_Id`       AS `type_Id`,
       `t`.`type_Name`     AS `type_Name`
from `cccar`.`car_info` `i`
         join `cccar`.`car_type` `t`
         join `cccar`.`net_info` `n`
         join `cccar`.`car_category` `c`
where ((`i`.`type_Id` = `t`.`type_Id`) and (`t`.`category_Id` = `c`.`category_Id`) and (`n`.`net_id` = `i`.`net_id`));

