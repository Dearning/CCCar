create definer = root@localhost view carandtype as
select `i`.`net_id` AS `net_id`, `i`.`car_id` AS `car_id`, `i`.`type_Id` AS `type_Id`, `t`.`type_Name` AS `type_Name`
from `cccar`.`car_info` `i`
         join `cccar`.`car_type` `t`
where (`i`.`type_Id` = `t`.`type_Id`);

