create definer = root@localhost view type_cate_car_net as
select `t`.`type_Id`              AS `type_Id`,
       `t`.`type_Name`            AS `type_Name`,
       `t`.`category_Id`          AS `category_Id`,
       `t`.`brand`                AS `brand`,
       `t`.`displacement`         AS `displacement`,
       `t`.`gear`                 AS `gear`,
       `t`.`seat_num`             AS `seat_num`,
       `t`.`price`                AS `price`,
       `t`.`pic`                  AS `pic`,
       `c`.`category_Name`        AS `category_Name`,
       `c`.`category_Description` AS `category_Description`,
       `i`.`car_id`               AS `car_id`,
       `i`.`license`              AS `license`,
       `i`.`car_status`           AS `car_status`,
       `n`.`net_id`               AS `net_id`,
       `n`.`net_name`             AS `net_name`,
       `n`.`city`                 AS `city`,
       `n`.`address`              AS `address`,
       `n`.`phone`                AS `phone`
from (((`cccar`.`car_type` `t` join `cccar`.`car_category` `c` on ((`t`.`category_Id` = `c`.`category_Id`))) join `cccar`.`car_info` `i` on ((`i`.`type_Id` = `t`.`type_Id`)))
         join `cccar`.`net_info` `n` on ((`i`.`net_id` = `n`.`net_id`)));

