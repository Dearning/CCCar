create definer = root@localhost view carallinfo as
select `i`.`car_id`       AS `car_id`,
       `t`.`type_Id`      AS `type_Id`,
       `t`.`type_Name`    AS `type_Name`,
       `t`.`category_Id`  AS `category_Id`,
       `t`.`brand`        AS `brand`,
       `t`.`displacement` AS `displacement`,
       `t`.`gear`         AS `gear`,
       `t`.`seat_num`     AS `seat_num`,
       `t`.`price`        AS `price`,
       `t`.`pic`          AS `pic`,
       `i`.`net_id`       AS `net_id`
from `cccar`.`car_info` `i`
         join `cccar`.`car_type` `t`
         join `cccar`.`car_category` `c`
where ((`i`.`type_Id` = `t`.`type_Id`) and (`t`.`category_Id` = `c`.`category_Id`));

